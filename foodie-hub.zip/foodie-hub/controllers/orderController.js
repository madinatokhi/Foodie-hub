const { pool } = require('../server');

// Place a new order
exports.placeOrder = async (req, res) => {
  const { customer_id, restaurant_id, items, status } = req.body;

  try {
    // 1. Create the order
    const orderResult = await pool.query(
      'INSERT INTO orders (customer_id, restaurant_id, status) VALUES ($1, $2, $3) RETURNING *',
      [customer_id, restaurant_id, status || 'pending']
    );

    const orderId = orderResult.rows[0].id;

    // 2. Add items to order_items table
    for (const item of items) {
      await pool.query(
        'INSERT INTO order_items (order_id, menu_item_id, quantity) VALUES ($1, $2, $3)',
        [orderId, item.menu_item_id, item.quantity]
      );
    }

    res.json({ message: 'Order placed successfully', orderId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get all orders (with optional status filter)
exports.getAllOrders = async (req, res) => {
  const { status } = req.query;

  try {
    let result;
    if (status) {
      result = await pool.query('SELECT * FROM orders WHERE status = $1', [status]);
    } else {
      result = await pool.query('SELECT * FROM orders');
    }

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get orders by customer
exports.getOrdersByCustomer = async (req, res) => {
  const customerId = req.params.id;

  try {
    const result = await pool.query(
      'SELECT * FROM orders WHERE customer_id = $1',
      [customerId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update order status
exports.updateOrderStatus = async (req, res) => {
  const orderId = req.params.id;
  const { status } = req.body;

  try {
    const result = await pool.query(
      'UPDATE orders SET status = $1 WHERE id = $2 RETURNING *',
      [status, orderId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Cancel an order
exports.cancelOrder = async (req, res) => {
  const orderId = req.params.id;

  try {
    await pool.query('DELETE FROM order_items WHERE order_id = $1', [orderId]);
    await pool.query('DELETE FROM orders WHERE id = $1', [orderId]);
    res.json({ message: 'Order canceled successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get all orders for a specific restaurant
exports.getOrdersByRestaurant = async (req, res) => {
  const restaurantId = req.params.id;

  try {
    const result = await pool.query(
      'SELECT * FROM orders WHERE restaurant_id = $1',
      [restaurantId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get most popular menu items (top selling)
exports.getPopularMenuItems = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        mi.id,
        mi.name,
        mi.price,
        COUNT(oi.menu_item_id) AS total_orders
      FROM 
        order_items oi
      JOIN 
        menu_items mi ON oi.menu_item_id = mi.id
      GROUP BY 
        mi.id, mi.name, mi.price
      ORDER BY 
        total_orders DESC
      LIMIT 10
    `);

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
