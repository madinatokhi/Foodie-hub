// controllers/restaurantController.js

const pool = require('../db');

exports.createRestaurant = async (req, res) => {
  const { name, location, phone } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO restaurants (name, location, phone) VALUES ($1, $2, $3) RETURNING *',
      [name, location, phone]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAllRestaurants = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM restaurants');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateRestaurant = async (req, res) => {
  const id = req.params.id;
  const { name, location, phone } = req.body;

  try {
    const result = await pool.query(
      'UPDATE restaurants SET name = $1, location = $2, phone = $3 WHERE id = $4 RETURNING *',
      [name, location, phone, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteRestaurant = async (req, res) => {
  const id = req.params.id;

  try {
    await pool.query('DELETE FROM restaurants WHERE id = $1', [id]);
    res.json({ message: 'Restaurant deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

