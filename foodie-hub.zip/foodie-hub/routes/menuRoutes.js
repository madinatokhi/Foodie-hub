// routes/menuRoutes.js
const express = require('express');
const router = express.Router();
const menuController = require('../controllers/menuController');

router.post('/restaurants/:id/menu-items', menuController.addMenuItem);
router.get('/restaurants/:id/menu-items', menuController.getMenuItemsByRestaurant);

router.put('/menu-items/:id', menuController.updateMenuItem);
router.delete('/menu-items/:id', menuController.deleteMenuItem);


module.exports = router;
