const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');

// POST - Add new customer
router.post('/customers', customerController.addCustomer);

// GET - Get all customers
router.get('/customers', customerController.getAllCustomers);

// PUT - Update customer
router.put('/customers/:id', customerController.updateCustomer);

// DELETE - Delete customer
router.delete('/customers/:id', customerController.deleteCustomer);

module.exports = router;
