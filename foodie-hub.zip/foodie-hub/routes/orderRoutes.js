const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Place a new order
router.post('/orders', orderController.placeOrder);

// Get all orders
router.get('/orders', orderController.getAllOrders);
router.get('/restaurant/:id', orderController.getOrdersByRestaurant);
router.get('/customers/:id/orders', orderController.getOrdersByCustomer);
router.get('/popular-menu-items', orderController.getPopularMenuItems);

// Update order status
router.put('/orders/:id', orderController.updateOrderStatus);

// Delete (cancel) an order
router.delete('/orders/:id', orderController.cancelOrder);

module.exports = router;
