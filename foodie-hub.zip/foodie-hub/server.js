const express = require('express');
const dotenv = require('dotenv');
const { Pool } = require('pg');
const app = express();

// Load environment variables
dotenv.config();

// PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Make pool available in all controllers
module.exports = { pool };

// Middleware
app.use(express.json());

// Routes
const restaurantRoutes = require('./routes/restaurantRoutes');
const menuRoutes = require('./routes/menuRoutes'); 
const customerRoutes = require('./routes/customerRoutes');
const orderRoutes = require('./routes/orderRoutes');




app.use('/restaurants', restaurantRoutes);
app.use('/', menuRoutes); 
app.use('/', customerRoutes);
app.use('/', orderRoutes);
app.use('/orders', orderRoutes);


// Root route
app.get('/', (req, res) => {
  res.send('Welcome to Foodie Hub Backend!');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
